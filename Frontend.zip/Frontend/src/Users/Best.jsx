import React from 'react'

const Best = () => {
  return (
    <div>
        <div className="flex flex-column max-h-96 p-3 ">
            <div className="w-52 h-52 p-3 border border-zinc-300">
                <img src="11.png" alt="" srcset="" className='h-40 w-44 object-contain '  />
            </div>
        </div>
      
    </div>
  )
}

export default Best

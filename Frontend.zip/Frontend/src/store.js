import { atomWithStorage } from 'jotai/utils'

export const productAtom = atomWithStorage("productid", "")